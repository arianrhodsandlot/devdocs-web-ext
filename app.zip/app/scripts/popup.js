/* global Backbone */
$(function() {
  var Entries = Backbone.Model.extend({
    fetch: function(query) {
      var that = this
      chrome.runtime.sendMessage(query, function(response) {
        that.clear()
        if (response.length) {
          that.set(response)
        }
      })
    }
  })
  var entries = new Entries()

  var Content = Backbone.Model.extend({
    defaults: {
      domain: 'maxcdn-docs.devdocs.io',
      category: '',
      path: '',
      hash: ''
    }
  })
  var content = new Content()

  var AppView = Backbone.View.extend({
    el: 'body',
    model: entries,
    events: {
      'input .input': 'search',
      'keydown .input': 'completeCategory',
      'keydown': 'pick'
    },
    initialize: function() {
      this.$input = $('.input')
      this.$results = $('.results')
      this.$splash = $('.splash')
      this.$content = $('.content')
    },
    search: _.debounce(function() {
      var query = this.$input.val()

      this.model.fetch(query)
    }, 200),
    completeCategory: function(e) { //to do
      return e.which !== 9
    },
    pick: function(e) {
      var keyCodes = {
        up: 38,
        down: 40,
        enter: 13
      };

      var $activeResult = this.$results.find('.active')
      var $firstResult = this.$results.find('.result:first')
      var $lastResult = this.$results.find('.result:last')
      var $nextResult = $activeResult.next()
      var $prevResult = $activeResult.prev()

      $nextResult = $nextResult.get(0) ? $nextResult : $firstResult
      $prevResult = $prevResult.get(0) ? $prevResult : $lastResult
      if (_.contains(_.values(_.pick(keyCodes, 'up', 'down')), e.which)) {
        $activeResult.removeClass('active')
        switch (e.which) {
          case 38:
            $prevResult.addClass('active')
              .get(0).scrollIntoView(false)
            break
          case 40:
            $nextResult.addClass('active')
              .get(0).scrollIntoView(false)
            break
        }
        return false
      } else if (e.which === keyCodes.enter) {
        resultsView.open()
        return false
      }
    }
  })

  var ResultsView = Backbone.View.extend({
    el: '.results',
    template: _.template($('.result-template').html()),
    model: entries,
    events: {
      'click .result': 'open',
      'mouseenter .result': 'highlight',
      'mouseleave .result': 'unhighlight'
    },
    initialize: function() {
      this.$splash = $('.splash')
      this.$content = $('.content')
      this.listenTo(this.model, 'change', this.render);
    },
    render: function() {
      var html = _.trim(this.template(this.model.attributes))
      this.$el.html(html)
      this.$content.addClass('hidden').empty()
      if (html) {
        this.$el.removeClass('hidden')
        this.$splash.addClass('hidden')
      } else {
        this.$el.addClass('hidden')
        this.$splash.removeClass('hidden')
      }
    },
    open: function(e) {
      var $target = this.$el.find('.active')
      var $content = $('.content')
      var pathAndHash = $target.data('path').split('#')
      var name = $target.html()
      var category = $target.data('category')
      var path = pathAndHash[0]
      var hash = pathAndHash[1]
      hash = hash ? '#' + hash : ''

      this.$el.addClass('hidden')

      if (path) {
        content.set({
          category: category,
          path: path,
          hash: hash
        })
      }
    },
    highlight: function(e) {
      $(e.target).addClass('active')
    },
    unhighlight: function(e) {
      $(e.target).removeClass('active')
    }
  })

  var ContentView = Backbone.View.extend({
    el: '.content',
    model: content,
    events: {
      'click a': 'redirect'
    },
    initialize: function() {
      this.listenTo(this.model, 'change', this.render)
    },
    render: function() {
      var that = this;
      var contentUrl = 'http://<%= obj.domain %>/<%= obj.category %>/<%= obj.path %>.html#<%= obj.hash %>';
      var hash = this.model.get('hash')
      var $content = this.$el
      var category = this.model.get('category')

      var newClass = 'content _'
      if (category === 'backbone') {
        newClass += 'underscore'
      } else {
        newClass += category
      }

      $content
        .attr('class', newClass)
        .html('<div class="loading-text">Loading...</div>')

      $.get(_.template(contentUrl)(this.model.attributes))
        .done(function(html) {
          $content.html(html)
          _.defer(function() {
            $content
              .scrollTop(0)
              .scrollTop(function() {
                var $target = $content.find(
                  _.contains(hash, '.') ?
                  '[id="' + hash.slice(1) + '"]' :
                  hash
                )

                return $target.get(0) ?
                  $target.offset()
                  .top - 54 :
                  0
              })

            //render iframe demos in jQuery documents
            $content
              .find('h4')
              .filter(function() {
                return $(this).html() === 'Demo:'
              })
              .after(function() {
                var $iframe = $('<iframe>')
                var demoHtml = _.unescape($(this).prev().html())

                demoHtml = demoHtml.replace(/"\/\/code.jquery.com\/jquery-1.10.2.js/, '"/bower_components/jquery/dist/jquery.min.js')

                _.defer(function() {
                  $iframe.contents().find('body').html(demoHtml)
                })
                return $iframe
              })
          })
        })
        .fail(function() {
          $content.html('<div class="loading-text">Connect failed...</div>')
        })
    },
    redirect: function(e) {
      var href = $(e.target).attr('href')
      var path = href.split('#')[0]
      var hash = href.split('#')[1]

      hash = hash ? hash : ''

      if (path) {
        this.model.set({
          path: path,
          hash: hash
        })
        return false
      } else {
        return true
      }
    }
  })

  var appView = new AppView()
  var resultsView = new ResultsView()
  var contentView = new ContentView()
  window.e = entries
  window.c = contentView
})
